<?php

function removeAccents($text) {
    $map = [
        'Ά' => 'Α', 'ά' => 'α', 'Έ' => 'Ε', 'έ' => 'ε', 'Ή' => 'Η', 'ή' => 'η',
        'Ό' => 'Ο', 'ό' => 'ο', 'Ύ' => 'Υ', 'ύ' => 'υ', 'Ϊ' => 'Ι', 'ί' => 'ι',
        'Ώ' => 'Ω', 'ώ' => 'ω', 'ΐ' => 'ι'
    ];
    return strtr($text, $map);
}

function createEmptyGrid($size) {
    $grid = [];
    for ($i = 0; $i < $size; $i++) {
        $grid[$i] = array_fill(0, $size, '');
    }
    return $grid;
}

function getRandomGreekLetter() {
    $letters = preg_split('//u', 'ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ', -1, PREG_SPLIT_NO_EMPTY);
    return $letters[array_rand($letters)];
}

function canPlaceWord($grid, $word, $row, $col, $dir, $size) {
    $len = mb_strlen($word);
    for ($i = 0; $i < $len; $i++) {
        $r = $row; $c = $col;
        switch ($dir) {
            case 'H': $c += $i; break;
            case 'V': $r += $i; break;
            case 'D': $r += $i; $c += $i; break;
        }
        if ($r >= $size || $c >= $size) return false;
        if ($grid[$r][$c] !== '' && $grid[$r][$c] !== mb_substr($word, $i, 1)) return false;
    }
    return true;
}

function placeWord(&$grid, $word, $size) {
    $directions = ['H', 'V', 'D'];
    $attempts = 100;
    while ($attempts--) {
        $dir = $directions[array_rand($directions)];
        $row = rand(0, $size - 1);
        $col = rand(0, $size - 1);
        if (canPlaceWord($grid, $word, $row, $col, $dir, $size)) {
            for ($i = 0; $i < mb_strlen($word); $i++) {
                $letter = mb_substr($word, $i, 1);
                switch ($dir) {
                    case 'H': $grid[$row][$col + $i] = $letter; break;
                    case 'V': $grid[$row + $i][$col] = $letter; break;
                    case 'D': $grid[$row + $i][$col + $i] = $letter; break;
                }
            }
            return true;
        }
    }
    return false;
}

function fillGrid(&$grid, $size) {
    for ($i = 0; $i < $size; $i++) {
        for ($j = 0; $j < $size; $j++) {
            if ($grid[$i][$j] === '') $grid[$i][$j] = getRandomGreekLetter();
        }
    }
}

function generateTimestamp() {
    $chars = '0123456789abcdef';
    $timestamp = '';
    for ($i = 0; $i < 12; $i++) $timestamp .= $chars[rand(0, strlen($chars) - 1)];
    return $timestamp;
}

function extractKeyWords($html) {
    $words = [];
    $text = strip_tags($html);
    $text = removeAccents($text);
    $text = preg_replace('/[^α-ωΑ-Ω\s]/u', ' ', $text);
    $text = preg_replace('/\s+/', ' ', $text);
    $allWords = preg_split('/\s+/', trim($text), -1, PREG_SPLIT_NO_EMPTY);
    $excludeWords = ['ΜΑΘΗΜΑ', 'ΜΑΘΗΜΑΟ', 'ΜΑΘΗΜΑΤΑ', 'ΜΑΘΗΜΑΤΟΣ'];
    foreach ($allWords as $word) {
        $word = trim($word);
        $len = mb_strlen($word);
        if ($len >= 4 && $len <= 15 && preg_match('/^[Α-Ω]+$/u', $word)) {
            if (!in_array($word, $excludeWords)) $words[$word] = $word;
        }
    }
    if (preg_match_all('/<b>([^<]+)<\/b>/u', $html, $matches)) {
        foreach ($matches[1] as $match) {
            $match = removeAccents($match);
            $match = preg_replace('/[^α-ωΑ-Ω]/u', '', $match);
            $match = mb_strtoupper($match);
            $len = mb_strlen($match);
            if ($len >= 3 && $len <= 15 && !in_array($match, $excludeWords)) $words[$match] = $match;
        }
    }
    return array_values($words);
}

function getLessonTitle($html, $num) {
    if (preg_match("/<title>[^-]*—[[:space:]]*Μάθημα[[:space:]]*{$num}:[[:space:]]*([^<]+)/u", $html, $m)) {
        return trim($m[1]);
    }
    if (preg_match("/Μάθημα[[:space:]]*{$num}[ο°]?[:]?[[:space:]]*([^<\\.\\-]+)/u", $html, $m)) {
        return trim($m[1]);
    }
    return "Μαθημα {$num}";
}

$classDirs = [
    'A' => '../HTML/Pliroforiki_A-Dimotikou_pdf-web_v6.0_PEDIO/lessons_seperated/',
    'B' => '../HTML/Pliroforiki_B-Dimotikou_pdf-web_v6.0_PEDIO/lessons_seperated/',
    'C' => '../HTML/Pliroforiki_C-Dimotikou_pdf-web_v.6.0_PEDIO/lessons_seperated/',
    'D' => '../HTML/Pliroforiki_D-dimotikou_light-web_v.5.0_PEDIO/lessons_seperated/',
    'E' => '../HTML/Pliroforiki_E-Dimotikou_vivlioMathiti-tetradioergasiwn_pdf-web_v6.0_PEDIO/lessons_seperated/',
    'ST' => '../HTML/Pliroforiki_ST-Dimotikou_pdf-web_v.7.0_PEDIO/lessons_seperated/'
];

function loadImportantWords($file) {
    $lines = file($file);
    $keywords = [];
    foreach ($lines as $line) {
        $line = trim($line);
        if (empty($line) || !preg_match("/^(dim[A-Z]+-les\\d+)/", $line, $m)) continue;
        $parts = explode("|", $line);
        if (count($parts) >= 4) {
            $kw = trim($parts[2]);
            $kw = explode(",", $kw);
            $keywords[$m[1]] = trim($kw[0]);
        }
    }
    return $keywords;
}

$importantWords = loadImportantWords('importantwords.txt');

$total = 0;
foreach ($classDirs as $class => $dir) {
    echo "=== Processing Class {$class} ===\n";
    for ($i = 1; $i <= 30; $i++) {
        $file = $dir . 'lesson' . sprintf('%02d', $i) . '.html';
        if (file_exists($file)) {
            $html = file_get_contents($file);
            $title = getLessonTitle($html, $i);
            $words = extractKeyWords($html);
            
            $cleanTitle = removeAccents($title);
            $cleanTitle = preg_replace('/[^α-ωΑ-Ω\s]/u', '', $cleanTitle);
            $tag = mb_strtolower(trim(preg_replace('/\s+/', ' ', $cleanTitle)));
            if (mb_strlen($tag) > 20) $tag = mb_substr($tag, 0, 20);
            
            $timestamp = generateTimestamp();
            $id = "dim{$class}-les" . sprintf('%02d', $i) . "-{$timestamp}";
            $filename = "{$id}.json";
            
            $fullTitle = "{$title} - Αναζητηση Λεξεων";
            
            $lessonId = "dim{$class}-les" . sprintf('%02d', $i);
            if (isset($importantWords[$lessonId])) {
                $selectedWords = [$importantWords[$lessonId]];
            } else {
                $selectedWords = [];
            }
            
            if (count($selectedWords) < 8) {
                foreach ($words as $w) {
                    if (count($selectedWords) >= 8) break;
                    if (!in_array($w, $selectedWords)) $selectedWords[] = $w;
                }
            }
            if (count($selectedWords) < 6) {
                $selectedWords = array_merge($selectedWords, ['ΑΛΓΟΡΙΘΜΟΣ', 'ΠΡΟΒΛΗΜΑ', 'ΛΥΣΗ', 'ΕΝΤΟΛΗ']);
            }
            $selectedWords = array_unique($selectedWords);
            $selectedWords = array_slice($selectedWords, 0, 8);
            
            $size = 12;
            $grid = createEmptyGrid($size);
            foreach ($selectedWords as $word) placeWord($grid, $word, $size);
            fillGrid($grid, $size);
            
            $json = [
                'id' => $id,
                'title' => $fullTitle,
                'type' => 'wordsearch',
                'created_by' => 'admin',
                'created_date' => date('Y-m-d'),
                'data' => [
                    'grid' => $grid,
                    'words' => $selectedWords
                ],
                'tags' => ["dim{$class}", "les" . sprintf('%02d', $i), $tag]
            ];
            
            file_put_contents($filename, json_encode($json, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
            echo "  {$filename}: " . implode(',', $selectedWords) . "\n";
            $total++;
        }
    }
}
echo "\n=== Total: {$total} files created ===\n";