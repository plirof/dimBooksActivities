<?php

function removeAccents($text) {
    $map = [
        'Ά' => 'Α', 'ά' => 'α', 'Έ' => 'Ε', 'έ' => 'ε', 'Ή' => 'Η', 'ή' => 'η',
        'Ό' => 'Ο', 'ό' => 'ο', 'Ύ' => 'Υ', 'ύ' => 'υ', 'Ϊ' => 'Ι', 'ί' => 'ι',
        'Ώ' => 'Ω', 'ώ' => 'ω', 'ΐ' => 'ι'
    ];
    return strtr($text, $map);
}

function getLessonTitle($html, $num) {
    if (preg_match("/<title>[^-]*—[[:space:]]*Μάθημα[[:space:]]*$num}:[[:space:]]*([^<]+)/u", $html, $m)) {
        return trim($m[1]);
    }
    if (preg_match("/Μάθημα[[:space:]]*$num[ο°]?[:]?[[:space:]]*([^<\\.\\-]+)/u", $html, $m)) {
        return trim($m[1]);
    }
    return "Μαθημα $num";
}

function getImportantKeyword($html, $title) {
    $title = removeAccents($title);
    $words = preg_split('/\\s+/', $title);
    
    foreach ($words as $word) {
        $clean = preg_replace('/[^Α-Ω]/u', '', $word);
        $clean = mb_strtoupper($clean);
        $len = mb_strlen($clean);
        $skip = ['ΑΠΟ', 'ΤΟΥ', 'ΤΗΣ', 'ΤΩΝ', 'ΤΟ', 'ΤΗΝ', 'ΤΑ', 'ΜΑΘΗΜΑ', 'ΤΙΣ'];
        if ($len >= 4 && !in_array($clean, $skip)) {
            return $clean;
        }
    }
    
    if (preg_match_all('/<b>([^<]+)<\\/b>/u', $html, $matches)) {
        foreach ($matches[1] as $match) {
            $clean = removeAccents($match);
            $clean = preg_replace('/[^Α-Ω]/u', '', $clean);
            $clean = mb_strtoupper($clean);
            if (mb_strlen($clean) >= 4 && $clean !== 'ΜΑΘΗΜΑ') {
                return $clean;
            }
        }
    }
    
    return null;
}

function getPageNumber($html) {
    if (preg_match('/<p[^>]*>(\\d+)<\\/p>/', $html, $m)) {
        return intval($m[1]);
    }
    return 0;
}

$classDirs = [
    'A' => '../HTML/Pliroforiki_A-Dimotikou_pdf-web_v6.0_PEDIO/lessons_seperated/',
    'B' => '../HTML/Pliroforiki_B-Dimotikou_pdf-web_v6.0_PEDIO/lessons_seperated/',
    'C' => '../HTML/Pliroforiki_C-Dimotikou_pdf-web_v.6.0_PEDIO/lessons_seperated/',
    'D' => '../HTML/Pliroforiki_D-dimotikou_light-web_v.5.0_PEDIO/lessons_seperated/',
    'E' => '../HTML/Pliroforiki_E-Dimotikou_vivlioMathiti-tetradioergasiwn_pdf-web_v6.0_PEDIO/lessons_seperated/',
    'ST' => '../HTML/Pliroforiki_ST-Dimotikou_pdf-web_v.7.0_PEDIO/lessons_seperated/'
];

$outputLines = [];
foreach ($classDirs as $class => $dir) {
    $outputLines[] = "=== CLASS $class ===";
    for ($i = 1; $i <= 30; $i++) {
        $file = $dir . 'lesson' . sprintf('%02d', $i) . '.html';
        if (file_exists($file)) {
            $html = file_get_contents($file);
            $title = getLessonTitle($html, $i);
            $keyword = getImportantKeyword($html, $title);
            if (!$keyword) $keyword = 'ΛΕΞΗ';
            
            $pageNum = getPageNumber($html);
            $slug = mb_strtolower(preg_replace('/[^α-ω]/u', '', removeAccents($title)));
            $slug = mb_substr($slug, 0, 20);
            
            $lessonId = "dim$class-les" . sprintf('%02d', $i);
            $dots = str_repeat('.', max(5, 60 - mb_strlen($title)));
            
            $outputLines[] = "$lessonId | $title $dots $pageNum | $keyword | $slug";
        }
    }
}

echo implode("\n", $outputLines);